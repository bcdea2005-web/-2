import { useCallback, useRef, useState } from "react";
import { AnimatePresence, motion, useScroll, useSpring } from "framer-motion";
import { CheckCircle2 } from "lucide-react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import SocialProof from "./components/SocialProof";
import Features from "./components/Features";
import MenuSection from "./components/MenuSection";
import Experience from "./components/Experience";
import Testimonials from "./components/Testimonials";
import Pricing from "./components/Pricing";
import FAQ from "./components/FAQ";
import CTA from "./components/CTA";
import Footer from "./components/Footer";
import type { Dish } from "./data/content";

interface Toast {
  id: number;
  message: string;
}

export default function App() {
  const [cartCount, setCartCount] = useState(0);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const idRef = useRef(0);

  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 90, damping: 24, mass: 0.4 });

  const handleAdd = useCallback((dish: Dish) => {
    setCartCount((c) => c + 1);
    const id = ++idRef.current;
    setToasts((t) => [...t, { id, message: `أُضيف «${dish.name}» إلى طلبك` }]);
    setTimeout(() => {
      setToasts((t) => t.filter((x) => x.id !== id));
    }, 2400);
  }, []);

  return (
    <div className="grain relative min-h-screen bg-ink-950 font-body text-cream-50">
      {/* skip link */}
      <a
        href="#menu"
        className="sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-[80] focus:rounded-full focus:bg-brand-400 focus:px-5 focus:py-2.5 focus:text-sm focus:font-black focus:text-ink-950"
      >
        تخطَّ إلى قائمة الطعام
      </a>

      {/* scroll progress */}
      <motion.div
        className="fixed inset-x-0 top-0 z-[60] h-[3px] origin-right bg-gradient-to-l from-brand-300 via-brand-400 to-brand-600"
        style={{ scaleX: progress }}
        aria-hidden="true"
      />

      <Navbar cartCount={cartCount} />

      <main>
        <Hero />
        <SocialProof />
        <Features />
        <MenuSection onAdd={handleAdd} />
        <Experience />
        <Testimonials />
        <Pricing />
        <FAQ />
        <CTA />
      </main>

      <Footer />

      {/* toasts */}
      <div className="pointer-events-none fixed bottom-6 start-1/2 z-[75] flex w-full max-w-sm -translate-x-1/2 flex-col items-center gap-2 px-4" aria-live="polite">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              layout
              initial={{ opacity: 0, y: 24, scale: 0.94 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 12, scale: 0.96 }}
              transition={{ type: "spring", stiffness: 420, damping: 30 }}
              className="glass-strong flex w-full items-center gap-3 rounded-2xl px-4 py-3 shadow-2xl"
            >
              <span className="grid size-8 shrink-0 place-items-center rounded-full bg-gradient-to-bl from-olive-400 to-brand-500">
                <CheckCircle2 className="size-4 text-ink-950" strokeWidth={2.5} />
              </span>
              <p className="text-sm font-bold text-cream-50">{t.message}</p>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
