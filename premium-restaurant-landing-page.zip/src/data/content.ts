export type CategoryId = "appetizers" | "mains" | "grills" | "desserts";

export interface Category {
  id: CategoryId;
  label: string;
  hint: string;
}

export interface Dish {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  category: CategoryId;
  badge?: string;
  rating: number;
  time: string;
  kcal: number;
}

export const categories: Category[] = [
  { id: "appetizers", label: "المقبلات", hint: "بداية تفتح الشهية" },
  { id: "mains", label: "الأطباق الرئيسية", hint: "قلب التجربة" },
  { id: "grills", label: "المشويات", hint: "على فحم البلوط" },
  { id: "desserts", label: "الحلو والمشروبات", hint: "الختام الأجمل" },
];

const img = (id: number, w = 900, h = 700) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

export const dishes: Dish[] = [
  // ── المقبلات ──
  {
    id: 1,
    name: "حمص بروفايل",
    description: "حمص حريري بزيت الزيتون البكر، صنوبر محمّص وخبزنا الذي يُخبز طازجاً كل ساعة.",
    price: 32,
    image: img(11842138),
    category: "appetizers",
    badge: "الأكثر طلباً",
    rating: 4.9,
    time: "10 د",
    kcal: 420,
  },
  {
    id: 2,
    name: "فلافل ذهبية",
    description: "فلافل مقرمشة بخلطة الأعشاب الطازجة، تُقدَّم مع طحينة الليمون المدخّن.",
    price: 26,
    image: img(29253319),
    category: "appetizers",
    rating: 4.8,
    time: "12 د",
    kcal: 380,
  },
  {
    id: 3,
    name: "متبل الموسم",
    description: "تشكيلة مقبلات: متبل باذنجان مدخّن، ورق عنب، وزيتون ومخللات بيتنا.",
    price: 38,
    image: img(9575814),
    category: "appetizers",
    badge: "للمشاركة",
    rating: 4.7,
    time: "8 د",
    kcal: 340,
  },
  // ── الأطباق الرئيسية ──
  {
    id: 4,
    name: "برجر بروفايل سيغنتشر",
    description: "لحم واغيو مدخّن، شيدر معتّقة، وصوصنا السري داخل بريوش يُخبز يومياً.",
    price: 58,
    image: img(5374421),
    category: "mains",
    badge: "اختيار الشيف",
    rating: 5.0,
    time: "18 د",
    kcal: 860,
  },
  {
    id: 5,
    name: "ألفريدو الدجاج بالترافل",
    description: "فيتوتشيني طازج بكريمة البارميزان وزيت الترافل مع دجاج مشوي على الفحم.",
    price: 62,
    image: img(11220208),
    category: "mains",
    rating: 4.9,
    time: "16 د",
    kcal: 720,
  },
  {
    id: 6,
    name: "سلمون مشوي بالأعشاب",
    description: "فيليه سلمون نرويجي بزبدة الليمون والأعشاب، مع خضار موسمية سوتيه.",
    price: 84,
    image: img(29168406),
    category: "mains",
    badge: "خيار صحي",
    rating: 4.8,
    time: "20 د",
    kcal: 540,
  },
  // ── المشويات ──
  {
    id: 7,
    name: "مشاوي مشكّلة على الفحم",
    description: "تتبيلة الفحم الخاصة: كباب حلبي، شيش طاووق، وتكة لحم غنم مع أرز عنبر.",
    price: 118,
    image: img(27668700),
    category: "grills",
    badge: "الأكثر طلباً",
    rating: 4.9,
    time: "25 د",
    kcal: 980,
  },
  {
    id: 8,
    name: "شيش طاووق بالثوم",
    description: "مكعبات دجاج متبّلة ١٢ ساعة باللبن والثوم، مع ثومية بروفايل الشهيرة.",
    price: 52,
    image: img(12738462),
    category: "grills",
    rating: 4.8,
    time: "22 د",
    kcal: 610,
  },
  {
    id: 9,
    name: "كباب حلبي",
    description: "لحم غنم مفروم ناعم ببهارات حلبية وبقدونس، يشوى على فحم البلوط.",
    price: 68,
    image: img(29259327),
    category: "grills",
    badge: "نكهة مدخّنة",
    rating: 4.7,
    time: "22 د",
    kcal: 690,
  },
  // ── الحلو والمشروبات ──
  {
    id: 10,
    name: "كنافة بالقشطة",
    description: "كنافة ناعمة بجبنة ذائبة وقطر ماء الورد، تُتوَّج بقشطة بلدية وفستق حلبي.",
    price: 36,
    image: img(29300027),
    category: "desserts",
    badge: "جديد",
    rating: 4.9,
    time: "12 د",
    kcal: 480,
  },
  {
    id: 11,
    name: "فوندان الشوكولاتة",
    description: "كيك شوكولاتة بلجيكية ٧٠٪ بقلب سائل، مع آيس كريم فانيليا مدغشقرية.",
    price: 38,
    image: img(31378003),
    category: "desserts",
    rating: 4.8,
    time: "14 د",
    kcal: 520,
  },
  {
    id: 12,
    name: "موهيتو بروفايل",
    description: "نعناع يُقطف صباحاً، ليمون طازج وصودا بثلج مجروش — انتعاش لا يُقاوَم.",
    price: 24,
    image: img(11009211),
    category: "desserts",
    rating: 4.7,
    time: "5 د",
    kcal: 120,
  },
];

export const heroImages = {
  main: img(37881956, 1000, 1300),
  secondary: img(29300027, 600, 600),
  side: img(29168406, 600, 400),
  chef: img(36073021, 1200, 900),
  grill: img(5779787, 800, 600),
};

export const ambienceVideo =
  "https://videos.pexels.com/video-files/34720127/14717545_3840_2160_24fps.mp4";

export interface Feature {
  icon: string;
  title: string;
  description: string;
}

export const features: Feature[] = [
  {
    icon: "Leaf",
    title: "مكونات تصلنا فجراً",
    description: "خضارنا من مزارع محلية ولحومنا طازجة يومياً — لا مجمّدات في مطبخنا أبداً.",
  },
  {
    icon: "ChefHat",
    title: "طهاة بجوايز عالمية",
    description: "فريق بقيادة الشيف التنفيذي الحائز على نجمتين، يعيد تقديم كل طبق كلوحة فنية.",
  },
  {
    icon: "Timer",
    title: "توصيل خلال 30 دقيقة",
    description: "تغليف حراري ذكي يحفظ الطبق كما لو خرج من المطبخ للتو — أو استرجع نقودك.",
  },
  {
    icon: "HeartPulse",
    title: "خيارات صحية محسوبة",
    description: "سعرات وماكروز موثّقة لكل طبق، مع مسارات كيتو ونباتية بلا أي تنازل عن النكهة.",
  },
  {
    icon: "Flame",
    title: "فحم البلوط الحقيقي",
    description: "مشوياتنا على فحم بلوط مستورد يمنح اللحم نكهة مدخّنة لا تقلّدها وسائل الغاز.",
  },
  {
    icon: "ShieldCheck",
    title: "جودة مضمونة 100%",
    description: "لم يعجبك الطبق؟ نعيد تحضيره أو نعيد ثمنه فوراً — بلا أسئلة، بلا تعقيد.",
  },
];

export interface Stat {
  value: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  label: string;
}

export const stats: Stat[] = [
  { value: 50, suffix: "K+", label: "عميل سعيد كل شهر" },
  { value: 4.9, decimals: 1, suffix: "/5", label: "متوسط تقييم الطعام" },
  { value: 120, suffix: "+", label: "طبق على القائمة" },
  { value: 98, suffix: "%", label: "يعودون خلال أسبوع" },
];

export const partners = ["هنقرستيشن", "جاهز", "ذا شيفز", "كريم ناو", "مرسول", "كيتوبي"];

export interface Testimonial {
  name: string;
  role: string;
  quote: string;
  rating: number;
  dish: string;
}

export const testimonials: Testimonial[] = [
  {
    name: "سارة المطيري",
    role: "مصممة جرافيك",
    quote:
      "برجر بروفايل غيّر مفهومي عن البرجر تماماً. الخبز، الصوص، درجة الاستواء — كل شيء مدروس. صرت أطلبه كل جمعة بلا استثناء.",
    rating: 5,
    dish: "برجر بروفايل سيغنتشر",
  },
  {
    name: "عبدالله الشهري",
    role: "رائد أعمال",
    quote:
      "أستقبل شركائي في العمل هنا منذ سنتين. الاتساق في الجودة هو ما يدهشني — الطبق الواحد يخرج بنفس الإتقان كل مرة.",
    rating: 5,
    dish: "مشاوي مشكّلة",
  },
  {
    name: "نورة القحطاني",
    role: "صانعة محتوى",
    quote:
      "صوّرت عشرات المطاعم، وقليل منها يسرق الكاميرا مثل أطباق بروفايل. التقديم فن، والطعم أجمل من الصورة — وهذا نادر.",
    rating: 5,
    dish: "سلمون مشوي بالأعشاب",
  },
  {
    name: "خالد العتيبي",
    role: "مهندس برمجيات",
    quote:
      "باقة الاشتراك الأسبوعية وفّرت عليّ عناء التفكير بالغداء. اختيارات متنوعة، سعرات محسوبة، ويصلني ساخناً في موعده دائماً.",
    rating: 4.9,
    dish: "باقة الاشتراك",
  },
];

export interface Plan {
  id: string;
  name: string;
  tagline: string;
  price: number;
  unit: string;
  popular?: boolean;
  features: string[];
  cta: string;
}

export const plans: Plan[] = [
  {
    id: "solo",
    name: "باقة سولو",
    tagline: "وجبتك اليومية بلا تفكير",
    price: 149,
    unit: "شهرياً",
    features: ["6 وجبات من قائمة الشيف", "اختيار المواعيد مسبقاً", "تغليف حراري مجاني", "إيقاف أو إلغاء في أي وقت"],
    cta: "ابدأ بـ سولو",
  },
  {
    id: "plus",
    name: "باقة بروفايل+",
    tagline: "الأكثر توازناً وقيمة",
    price: 289,
    unit: "شهرياً",
    popular: true,
    features: [
      "14 وجبة رئيسية + مقبلات",
      "مشروب مجاني مع كل وجبة",
      "توصيل مجاني أولوية",
      "خصم 20% على الحلويات",
      "هدية طبق الموسم الجديد",
    ],
    cta: "اشترك في بروفايل+",
  },
  {
    id: "vip",
    name: "باقة التذوق VIP",
    tagline: "لعشّاق التجربة الكاملة",
    price: 549,
    unit: "شهرياً",
    features: [
      "24 وجبة بلا حدود من القائمة",
      "طبق حلو أسبوعي مجاني",
      "دعوة تذوق الأطباق الجديدة",
      "طاولة شرف عند كل حجز",
      "مدير حساب شخصي",
    ],
    cta: "احجز مقعدك",
  },
];

export interface Faq {
  q: string;
  a: string;
}

export const faqs: Faq[] = [
  {
    q: "كيف أحجز طاولة في بروفايل؟",
    a: "الحجز يستغرق أقل من دقيقة: اختر الفرع والوقت من صفحة الحجز، وسيصلك تأكيد فوري برسالة نصية. ننصح بالحجز قبل 24 ساعة في عطلة نهاية الأسبوع لضمان طاولتك المفضلة.",
  },
  {
    q: "كم يستغرق التوصيل؟",
    a: "نلتزم بـ 30 دقيقة كحد أقصى داخل نطاق التغطية، بتغليف حراري يحفظ الحرارة والقوام. إن تأخر طلبك عن ذلك، يعود ثمن التوصيل إليك تلقائياً.",
  },
  {
    q: "هل توجد خيارات نباتية أو خالية من الغلوتين؟",
    a: "نعم — أكثر من 25 طبقاً نباتياً ومسار كامل خالٍ من الغلوتين. كل طبق موثّق بمكوناته وسعراته، ويمكنك تفعيل فلتر الحساسية داخل القائمة لترى ما يناسبك فقط.",
  },
  {
    q: "كيف تعمل باقات الاشتراك الشهرية؟",
    a: "تختار باقتك، تحدد مواعيدك الأسبوعية، ونحن نتكفل بالباقي. يمكنك تبديل الأطباق حتى منتصف الليل قبل يوم التوصيل، وإيقاف الباقة أو إلغاءها في أي وقت دون رسوم.",
  },
  {
    q: "ما طرق الدفع المتاحة؟",
    a: "مدى، أبل باي، بطاقات فيزا وماستركارد، والدفع عند الاستلام. جميع عمليات الدفع مشفّرة وآمنة بالكامل، ويمكنك حفظ أكثر من وسيلة في حسابك.",
  },
  {
    q: "هل تستضيفون المناسبات الخاصة؟",
    a: "بالتأكيد — لدينا قاعة خاصة تتسع لـ 30 ضيفاً وقائمة مناسبات مخصصة يصممها الشيف معك. تواصل معنا قبل 72 ساعة على الأقل وسنهتم بكل التفاصيل.",
  },
];
