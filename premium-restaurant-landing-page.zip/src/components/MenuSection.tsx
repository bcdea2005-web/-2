import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Star, Clock, Plus, Check, Flame } from "lucide-react";
import { categories, dishes, type CategoryId, type Dish } from "../data/content";
import { Reveal, SectionHeading } from "./ui";
import { cn } from "../utils/cn";

function DishCard({ dish, onAdd, index }: { dish: Dish; onAdd: (d: Dish) => void; index: number }) {
  const [added, setAdded] = useState(false);

  useEffect(() => {
    if (!added) return;
    const t = setTimeout(() => setAdded(false), 1600);
    return () => clearTimeout(t);
  }, [added]);

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 32, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.92, transition: { duration: 0.22 } }}
      transition={{ duration: 0.55, delay: index * 0.06, ease: [0.22, 1, 0.36, 1] }}
      className="group relative overflow-hidden rounded-[1.75rem] glass transition-all duration-500 hover:-translate-y-2 hover:border-brand-300/30 hover:shadow-[0_36px_70px_-24px_rgba(238,169,71,0.22)]"
    >
      {/* image */}
      <div className="relative overflow-hidden">
        <img
          src={dish.image}
          alt={dish.name}
          loading="lazy"
          className="aspect-[5/4] w-full object-cover transition-transform duration-[1.2s] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.08]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-900 via-ink-900/10 to-transparent" aria-hidden="true" />
        {dish.badge && (
          <span className="absolute start-3.5 top-3.5 inline-flex items-center gap-1.5 rounded-full bg-ink-950/70 px-3 py-1.5 text-[11px] font-black text-brand-200 backdrop-blur-md border border-brand-300/25">
            <Flame className="size-3 text-brand-400" aria-hidden="true" />
            {dish.badge}
          </span>
        )}
        <span className="absolute end-3.5 top-3.5 inline-flex items-center gap-1 rounded-full bg-ink-950/70 px-2.5 py-1.5 text-[11px] font-bold text-cream-100 backdrop-blur-md border border-cream-50/10">
          <Clock className="size-3 text-brand-300" aria-hidden="true" />
          <span className="tnum">{dish.time}</span>
        </span>
        {/* price chip */}
        <span className="absolute bottom-3.5 end-3.5 rounded-2xl bg-gradient-to-bl from-brand-300 to-brand-600 px-3.5 py-1.5 font-display text-base font-black text-ink-950 shadow-lg">
          <span className="tnum" dir="ltr">{dish.price}</span>
          <span className="ms-1 text-[11px] font-bold">ر.س</span>
        </span>
      </div>

      {/* body */}
      <div className="p-5 sm:p-6">
        <div className="flex items-start justify-between gap-3">
          <h3 className="font-display text-lg font-extrabold text-cream-50 leading-7">{dish.name}</h3>
          <span className="mt-1 inline-flex shrink-0 items-center gap-1 text-sm font-black text-brand-300">
            <Star className="size-3.5 fill-brand-400 text-brand-400" aria-hidden="true" />
            <span className="tnum">{dish.rating.toFixed(1)}</span>
          </span>
        </div>
        <p className="mt-2 text-[13.5px] leading-6 text-cream-300/85 line-clamp-2">{dish.description}</p>

        <div className="mt-5 flex items-center justify-between">
          <span className="text-[12px] font-semibold text-cream-400 tnum" dir="ltr">
            {dish.kcal} kcal
          </span>
          <motion.button
            type="button"
            whileTap={{ scale: 0.9 }}
            onClick={() => {
              setAdded(true);
              onAdd(dish);
            }}
            aria-label={`أضف ${dish.name} إلى طلبك`}
            className={cn(
              "relative inline-flex items-center gap-2 overflow-hidden rounded-full px-5 py-2.5 text-[13px] font-black transition-all duration-300",
              added
                ? "bg-olive-400 text-ink-950"
                : "bg-gradient-to-bl from-brand-300 to-brand-600 text-ink-950 hover:shadow-[0_10px_30px_-8px_rgba(238,169,71,0.65)]"
            )}
          >
            <AnimatePresence mode="wait" initial={false}>
              {added ? (
                <motion.span
                  key="check"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="flex items-center gap-1.5"
                >
                  <Check className="size-4" strokeWidth={3} />
                  أُضيف!
                </motion.span>
              ) : (
                <motion.span
                  key="plus"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="flex items-center gap-1.5"
                >
                  <Plus className="size-4" strokeWidth={3} />
                  أضف لطلبي
                </motion.span>
              )}
            </AnimatePresence>
          </motion.button>
        </div>
      </div>
    </motion.article>
  );
}

export default function MenuSection({ onAdd }: { onAdd: (d: Dish) => void }) {
  const [active, setActive] = useState<CategoryId>("appetizers");
  const filtered = dishes.filter((d) => d.category === active);
  const activeCat = categories.find((c) => c.id === active)!;

  return (
    <section id="menu" className="relative py-20 sm:py-28" aria-labelledby="menu-title">
      {/* ambient */}
      <div
        className="pointer-events-none absolute end-[-12%] top-16 size-[520px] rounded-full bg-brand-500/[0.08] blur-[140px]"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute start-[-10%] bottom-10 size-[420px] rounded-full bg-blush-400/[0.06] blur-[120px]"
        aria-hidden="true"
      />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          id="menu-title"
          tag="قائمة الطعام"
          title="قائمة تُقرأ بعينيك،"
          highlight="وتُذاق بحواسك كلها"
          description="أكثر من 120 طبقاً يتجدد كل موسم — هذه مختارات الشيف الأعلى تقييماً هذا الشهر."
        />

        {/* tabs */}
        <Reveal delay={0.15} className="mt-12">
          <div
            role="tablist"
            aria-label="تصنيفات القائمة"
            className="no-scrollbar mx-auto flex max-w-fit gap-2 overflow-x-auto rounded-full glass p-2"
          >
            {categories.map((c) => {
              const selected = c.id === active;
              return (
                <button
                  key={c.id}
                  role="tab"
                  aria-selected={selected}
                  aria-controls="menu-grid"
                  id={`tab-${c.id}`}
                  onClick={() => setActive(c.id)}
                  className={cn(
                    "relative shrink-0 rounded-full px-5 py-2.5 text-[14px] font-bold transition-colors duration-300 sm:px-6",
                    selected ? "text-ink-950" : "text-cream-200/75 hover:text-cream-50"
                  )}
                >
                  {selected && (
                    <motion.span
                      layoutId="tab-pill"
                      transition={{ type: "spring", stiffness: 380, damping: 32 }}
                      className="absolute inset-0 rounded-full bg-gradient-to-bl from-brand-300 to-brand-600 shadow-[0_8px_26px_-8px_rgba(238,169,71,0.7)]"
                    />
                  )}
                  <span className="relative">{c.label}</span>
                </button>
              );
            })}
          </div>
          <p className="mt-4 text-center text-sm text-cream-400" aria-live="polite">
            {activeCat.hint} — <span className="tnum text-brand-300">{filtered.length}</span> أطباق مختارة
          </p>
        </Reveal>

        {/* grid */}
        <motion.div
          id="menu-grid"
          role="tabpanel"
          aria-labelledby={`tab-${active}`}
          layout
          className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
        >
          <AnimatePresence mode="popLayout">
            {filtered.map((d, i) => (
              <DishCard key={d.id} dish={d} index={i} onAdd={onAdd} />
            ))}
          </AnimatePresence>
        </motion.div>

        {/* footer CTA */}
        <Reveal delay={0.1} className="mt-12 text-center">
          <p className="text-sm leading-7 text-cream-400">
            هذه نبذة فقط — القائمة الكاملة تضم أكثر من <span className="tnum font-bold text-cream-100">120</span> طبقاً
          </p>
          <a
            href="#cta"
            className="group mt-4 inline-flex items-center gap-2 font-display text-lg font-extrabold text-brand-300 transition-colors hover:text-brand-200"
          >
            اطلب القائمة الكاملة عند الحجز
            <span
              className="block h-px w-full bg-gradient-to-l from-brand-300 to-transparent transition-transform duration-500 group-hover:scale-x-110"
              aria-hidden="true"
            />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
