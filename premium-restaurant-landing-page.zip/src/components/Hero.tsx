import { useRef } from "react";
import { motion, useScroll, useTransform, useReducedMotion } from "framer-motion";
import { Star, Flame, ArrowDown, Sparkles, MapPin } from "lucide-react";
import { heroImages } from "../data/content";
import { GlowButton } from "./ui";

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12, delayChildren: 0.15 } },
};
const item = {
  hidden: { opacity: 0, y: 34, filter: "blur(8px)" },
  show: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { duration: 1, ease: [0.22, 1, 0.36, 1] as const },
  },
};

export default function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const yMain = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : 110]);
  const yCard = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : 60]);
  const fade = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  return (
    <section ref={ref} id="top" className="relative overflow-hidden pt-32 pb-16 sm:pt-40 lg:pb-24" aria-label="مقدمة المطعم">
      {/* ── Ambient background ── */}
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <div className="absolute -top-40 start-[-10%] size-[560px] rounded-full bg-brand-500/[0.13] blur-[130px] animate-pulse-glow" />
        <div className="absolute top-1/3 end-[-12%] size-[520px] rounded-full bg-blush-400/[0.08] blur-[140px]" />
        <div className="absolute bottom-[-20%] start-1/3 size-[460px] rounded-full bg-brand-600/[0.07] blur-[120px]" />
        {/* grid fade */}
        <div
          className="absolute inset-0 opacity-[0.14] [mask-image:radial-gradient(ellipse_75%_60%_at_50%_0%,black,transparent)]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(244,237,220,0.09) 1px, transparent 1px), linear-gradient(90deg, rgba(244,237,220,0.09) 1px, transparent 1px)",
            backgroundSize: "72px 72px",
          }}
        />
      </div>

      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-2 lg:gap-8">
        {/* ── Copy ── */}
        <motion.div variants={container} initial="hidden" animate="show" className="relative z-10">
          <motion.div variants={item}>
            <span className="inline-flex items-center gap-2.5 rounded-full glass px-4 py-2 text-[13px] font-semibold text-cream-100">
              <span className="flex -space-x-1" dir="ltr" aria-hidden="true">
                {[...Array(3)].map((_, i) => (
                  <Star key={i} className="size-3.5 fill-brand-400 text-brand-400" />
                ))}
              </span>
              <span>
                <strong className="tnum text-brand-200">4.9</strong> من أكثر من 8,400 تقييم موثّق
              </span>
            </span>
          </motion.div>

          <motion.h1
            variants={item}
            className="balanced mt-7 font-display text-[2.6rem] font-black leading-[1.18] text-cream-50 sm:text-6xl lg:text-[4.2rem]"
          >
            نكهةٌ تُعرّف عنك،
            <br />
            <span className="text-brand-gradient">وتبقى في الذاكرة</span>
          </motion.h1>

          <motion.p variants={item} className="mt-6 max-w-xl text-lg leading-9 text-cream-300">
            في مطعم <strong className="text-cream-100">بروفايل</strong> لا نطبخ أطباقاً فحسب — بل نصمّم توقيعك الخاص على
            الطاولة. مكونات تصلنا فجراً، فحم بلوط حقيقي، وقائمة تتجدد كل موسم لتروي قصتك.
          </motion.p>

          <motion.div variants={item} className="mt-9 flex flex-wrap items-center gap-4">
            <GlowButton href="#menu" ariaLabel="استكشف قائمة الطعام">
              استكشف القائمة
              <ArrowDown className="size-4 transition-transform duration-300 group-hover:translate-y-0.5" />
            </GlowButton>
            <GlowButton href="#plans" variant="ghost" ariaLabel="اكتشف باقات الاشتراك">
              <Sparkles className="size-4 text-brand-300" />
              باقات الاشتراك
            </GlowButton>
          </motion.div>

          <motion.div variants={item} className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-4">
            <div className="flex items-center gap-3">
              <div className="flex -space-x-3" dir="ltr" aria-hidden="true">
                {["س", "ع", "ن", "خ"].map((ch, i) => (
                  <span
                    key={i}
                    className="grid size-10 place-items-center rounded-full border-2 border-ink-950 bg-gradient-to-bl from-ink-700 to-ink-800 text-[13px] font-black text-brand-200"
                  >
                    {ch}
                  </span>
                ))}
              </div>
              <p className="text-sm leading-6 text-cream-300">
                انضم إلى <strong className="tnum text-cream-50">50,000+</strong> ضيف
                <br />
                يختارون بروفايل كل شهر
              </p>
            </div>
            <div className="hidden items-center gap-2 text-sm text-cream-400 sm:flex">
              <MapPin className="size-4 text-brand-400" />
              الرياض • جدة • الخبر
            </div>
          </motion.div>
        </motion.div>

        {/* ── Visual composition ── */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
          className="relative mx-auto w-full max-w-[520px]"
        >
          {/* conic halo */}
          <div
            className="absolute inset-[-8%] rounded-[3rem] opacity-60 animate-spin-slower"
            style={{
              background:
                "conic-gradient(from 90deg, transparent 0deg, rgba(238,169,71,0.35) 60deg, transparent 120deg, rgba(229,112,60,0.25) 220deg, transparent 300deg)",
              filter: "blur(28px)",
            }}
            aria-hidden="true"
          />

          {/* main dish */}
          <motion.div style={{ y: yMain, opacity: fade }} className="relative">
            <div className="ring-gradient overflow-hidden rounded-[2.5rem]">
              <img
                src={heroImages.main}
                alt="برجر بروفايل سيغنتشر بالخضار الطازجة على خلفية داكنة"
                className="aspect-[4/5] w-full object-cover"
                loading="eager"
                fetchPriority="high"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950/60 via-transparent to-transparent" aria-hidden="true" />
            </div>

            {/* floating: rating card */}
            <motion.div
              style={{ y: yCard }}
              className="absolute -start-4 top-8 sm:-start-10"
            >
              <div className="glass-strong rounded-2xl px-4 py-3 shadow-2xl animate-float-slow">
                <div className="flex items-center gap-2.5">
                  <span className="grid size-9 place-items-center rounded-xl bg-gradient-to-bl from-brand-300 to-brand-600">
                    <Star className="size-4 fill-ink-950 text-ink-950" />
                  </span>
                  <div>
                    <p className="text-[15px] font-black text-cream-50 tnum leading-5">4.9/5</p>
                    <p className="text-[11px] text-cream-400">أعلى تقييم بالرياض</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* floating: flame card */}
            <motion.div style={{ y: yCard }} className="absolute -end-3 bottom-24 sm:-end-8">
              <div className="glass-strong rounded-2xl px-4 py-3 shadow-2xl animate-float-slower">
                <div className="flex items-center gap-2.5">
                  <span className="relative grid size-9 place-items-center rounded-xl bg-gradient-to-bl from-blush-400 to-brand-600">
                    <Flame className="size-4 text-ink-950" />
                    <span className="absolute -top-0.5 -end-0.5 size-2 rounded-full bg-brand-300 animate-ping" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="text-[15px] font-black text-cream-50 leading-5">الأكثر طلباً</p>
                    <p className="text-[11px] text-cream-400">برجر بروفايل سيغنتشر</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* bottom bar inside image */}
            <div className="absolute inset-x-4 bottom-4">
              <div className="glass-strong flex items-center justify-between rounded-2xl px-5 py-3.5">
                <div>
                  <p className="text-sm font-black text-cream-50">طبق اليوم</p>
                  <p className="text-xs text-cream-300">سلمون الأعشاب بزبدة الليمون</p>
                </div>
                <a
                  href="#menu"
                  className="rounded-full bg-gradient-to-bl from-brand-300 to-brand-600 px-4 py-2 text-xs font-black text-ink-950 transition-transform hover:scale-105"
                >
                  اطلبه الآن
                </a>
              </div>
            </div>
          </motion.div>

          {/* side polaroid */}
          <motion.div
            style={{ y: yCard }}
            className="absolute -bottom-10 -start-6 hidden w-44 rotate-[-7deg] sm:block"
            aria-hidden="true"
          >
            <div className="glass-strong rounded-3xl p-2.5 shadow-2xl">
              <img src={heroImages.side} alt="" className="aspect-[4/3] w-full rounded-2xl object-cover" loading="lazy" />
              <p className="px-2 py-2 text-center text-[11px] font-bold text-cream-200">سلمون مشوي بالأعشاب</p>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* scroll cue */}
      <motion.a
        href="#proof"
        style={{ opacity: fade }}
        className="absolute bottom-6 start-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-cream-400 transition-colors hover:text-brand-300 lg:flex"
        aria-label="مرر للأسفل"
      >
        <span className="text-[11px] font-semibold tracking-widest">اكتشف المزيد</span>
        <motion.span
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          className="grid size-9 place-items-center rounded-full border border-cream-50/15"
        >
          <ArrowDown className="size-4" />
        </motion.span>
      </motion.a>
    </section>
  );
}
