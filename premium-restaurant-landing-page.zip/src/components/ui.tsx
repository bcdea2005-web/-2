import { useEffect, useRef, type ReactNode } from "react";
import { motion, useInView, useMotionValue, useSpring, useReducedMotion } from "framer-motion";
import { cn } from "../utils/cn";

/* ── Scroll reveal wrapper ─────────────────────────────── */
export function Reveal({
  children,
  delay = 0,
  y = 28,
  className,
  once = true,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
  once?: boolean;
}) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: reduce ? 0 : y, filter: "blur(6px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once, margin: "-80px" }}
      transition={{ duration: 0.9, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

/* ── Section eyebrow tag ───────────────────────────────── */
export function SectionTag({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-[13px] font-semibold tracking-wide text-brand-200",
        className
      )}
    >
      <span className="size-1.5 rounded-full bg-gradient-to-br from-brand-300 to-brand-500 shadow-[0_0_10px_2px_rgba(238,169,71,0.5)]" />
      {children}
    </span>
  );
}

/* ── Section heading block ─────────────────────────────── */
export function SectionHeading({
  tag,
  title,
  highlight,
  description,
  align = "center",
  id,
}: {
  tag: string;
  title: string;
  highlight?: string;
  description?: string;
  align?: "center" | "start";
  id?: string;
}) {
  const centered = align === "center";
  return (
    <div className={cn("max-w-2xl", centered ? "mx-auto text-center" : "text-start")}>
      <Reveal>
        <SectionTag>{tag}</SectionTag>
      </Reveal>
      <Reveal delay={0.08}>
        <h2
          id={id}
          className="balanced mt-5 font-display text-3xl font-black leading-[1.25] text-cream-50 sm:text-4xl lg:text-[2.75rem]"
        >
          {title} {highlight ? <span className="text-brand-gradient">{highlight}</span> : null}
        </h2>
      </Reveal>
      {description ? (
        <Reveal delay={0.16}>
          <p className="mt-4 text-base leading-8 text-cream-300/90 sm:text-lg">{description}</p>
        </Reveal>
      ) : null}
    </div>
  );
}

/* ── Count-up number ───────────────────────────────────── */
export function CountUp({
  value,
  decimals = 0,
  suffix = "",
  prefix = "",
  className,
}: {
  value: number;
  decimals?: number;
  suffix?: string;
  prefix?: string;
  className?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  const mv = useMotionValue(0);
  const spring = useSpring(mv, { stiffness: 42, damping: 18 });

  useEffect(() => {
    if (inView) mv.set(value);
  }, [inView, value, mv]);

  useEffect(() => {
    const unsub = spring.on("change", (v) => {
      if (ref.current) {
        ref.current.textContent = `${prefix}${v.toLocaleString("en-US", {
          minimumFractionDigits: decimals,
          maximumFractionDigits: decimals,
        })}${suffix}`;
      }
    });
    return unsub;
  }, [spring, decimals, suffix, prefix]);

  return (
    <span ref={ref} className={cn("tnum", className)} dir="ltr">
      {prefix}0{suffix}
    </span>
  );
}

/* ── Primary glow button ───────────────────────────────── */
export function GlowButton({
  children,
  href = "#",
  onClick,
  variant = "primary",
  className,
  ariaLabel,
}: {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: "primary" | "ghost";
  className?: string;
  ariaLabel?: string;
}) {
  const inner = (
    <>
      {variant === "primary" && (
        <span className="absolute inset-0 -z-10 rounded-full bg-gradient-to-bl from-brand-300 via-brand-400 to-brand-600 transition-all duration-500 group-hover:blur-[2px]" />
      )}
      {children}
    </>
  );
  const base = cn(
    "group relative inline-flex items-center justify-center gap-2.5 rounded-full px-7 py-3.5 text-[15px] font-bold transition-all duration-300 will-change-transform",
    variant === "primary"
      ? "text-ink-950 shadow-[0_10px_40px_-8px_rgba(238,169,71,0.55)] hover:shadow-[0_16px_50px_-6px_rgba(238,169,71,0.7)] hover:-translate-y-0.5 active:translate-y-0 overflow-hidden"
      : "glass text-cream-50 hover:border-brand-300/40 hover:bg-cream-50/[0.07] hover:-translate-y-0.5 active:translate-y-0",
    className
  );

  if (onClick) {
    return (
      <button type="button" onClick={onClick} className={base} aria-label={ariaLabel}>
        {inner}
      </button>
    );
  }
  return (
    <a href={href} className={base} aria-label={ariaLabel}>
      {inner}
    </a>
  );
}
