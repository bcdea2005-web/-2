import { BadgeCheck, CookingPot, PackageCheck, MousePointerClick } from "lucide-react";
import { heroImages } from "../data/content";
import { Reveal, SectionTag } from "./ui";

const checks = [
  { title: "وصفات لا تجدها إلا هنا", desc: "كل طبق يحمل لمسة شيفنا الخاصة — لا نسخ، لا تقليد." },
  { title: "شفافية كاملة في المطبخ", desc: "مطبخ مفتوح، ومكونات موثّقة المصدر من المزرعة إلى الطاولة." },
  { title: "تجربة تتكيف معك", desc: "القائمة تتذكر تفضيلاتك وتقترح ما يشبه ذوقك في كل زيارة." },
];

const steps = [
  {
    icon: MousePointerClick,
    num: "01",
    title: "اختر ما يشتهيه قلبك",
    desc: "تصفح القائمة، فعّل فلاتر الحساسية أو السعرات، وأضف أطباقك في ثوانٍ.",
  },
  {
    icon: CookingPot,
    num: "02",
    title: "الشيف يبدأ فوراً",
    desc: "يبدأ التحضير لحظة تأكيد طلبك — لا أطباق جاهزة، لا انتظار مجهول.",
  },
  {
    icon: PackageCheck,
    num: "03",
    title: "تصلك كما خرجت من المطبخ",
    desc: "تغليف حراري ذكي وسائق مخصص — طبقك يصل ساخناً خلال 30 دقيقة.",
  },
];

export default function Experience() {
  return (
    <section id="experience" className="relative py-20 sm:py-28" aria-labelledby="experience-title">
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid items-center gap-14 lg:grid-cols-2 lg:gap-20">
          {/* ── Visual collage ── */}
          <div className="relative order-2 lg:order-1">
            <div
              className="pointer-events-none absolute -inset-10 rounded-[3rem] bg-brand-500/[0.06] blur-[100px]"
              aria-hidden="true"
            />
            <Reveal>
              <div className="ring-gradient relative overflow-hidden rounded-[2.5rem]">
                <img
                  src={heroImages.chef}
                  alt="شيف بروفايل يطهو بجوار النار في مطبخ مفتوح"
                  loading="lazy"
                  className="aspect-[4/3] w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/70 via-transparent to-transparent" aria-hidden="true" />
                <div className="absolute bottom-5 start-5 end-5">
                  <p className="font-display text-xl font-extrabold text-cream-50">مطبخنا المفتوح</p>
                  <p className="text-sm text-cream-300">حيث يتحول الفحم إلى فن كل مساء</p>
                </div>
              </div>
            </Reveal>

            <Reveal delay={0.2} className="absolute -bottom-8 -end-4 w-44 sm:-end-8 sm:w-56">
              <div className="glass-strong rotate-[5deg] rounded-3xl p-2.5 shadow-2xl animate-float-slower">
                <img
                  src={heroImages.grill}
                  alt="شيف يشوي الكباب على اللهب المفتوح"
                  loading="lazy"
                  className="aspect-[4/3] w-full rounded-2xl object-cover"
                />
              </div>
            </Reveal>

            <Reveal delay={0.3} className="absolute -top-7 -start-3 sm:-start-7">
              <div className="glass-strong flex items-center gap-3 rounded-2xl px-4 py-3 shadow-2xl animate-float-slow">
                <span className="font-display text-3xl font-black text-brand-gradient tnum">12</span>
                <span className="text-xs font-bold leading-5 text-cream-200">
                  سنة من الشغف
                  <br />
                  بالنكهة العربية
                </span>
              </div>
            </Reveal>
          </div>

          {/* ── Copy ── */}
          <div className="order-1 lg:order-2">
            <Reveal>
              <SectionTag>تجربة بروفايل</SectionTag>
            </Reveal>
            <Reveal delay={0.08}>
              <h2
                id="experience-title"
                className="balanced mt-5 font-display text-3xl font-black leading-[1.25] text-cream-50 sm:text-4xl lg:text-[2.75rem]"
              >
                صُممت كل تفصيلة <span className="text-brand-gradient">لتشعر أنها لك وحدك</span>
              </h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mt-5 text-lg leading-9 text-cream-300">
                من لحظة فتحك للقائمة حتى آخر قطعة حلو، نبني حولك تجربة شخصية لا تتكرر مرتين — لأن النكهة الحقيقية تبدأ من
                معرفتنا بك.
              </p>
            </Reveal>

            <ul className="mt-8 space-y-5">
              {checks.map((c, i) => (
                <Reveal key={c.title} delay={0.2 + i * 0.1}>
                  <li className="group flex items-start gap-4">
                    <span className="mt-0.5 grid size-9 shrink-0 place-items-center rounded-xl bg-gradient-to-bl from-brand-300/15 to-brand-600/15 border border-brand-300/25 text-brand-300 transition-all duration-500 group-hover:from-brand-300 group-hover:to-brand-600 group-hover:text-ink-950">
                      <BadgeCheck className="size-4.5" strokeWidth={2.4} />
                    </span>
                    <div>
                      <h3 className="font-display text-lg font-extrabold text-cream-50">{c.title}</h3>
                      <p className="mt-1 text-[15px] leading-7 text-cream-300/90">{c.desc}</p>
                    </div>
                  </li>
                </Reveal>
              ))}
            </ul>
          </div>
        </div>

        {/* ── Steps ── */}
        <div className="mt-24 grid gap-5 md:grid-cols-3">
          {steps.map((s, i) => (
            <Reveal key={s.num} delay={i * 0.12}>
              <div className="group relative h-full overflow-hidden rounded-[1.75rem] glass p-7 transition-all duration-500 hover:-translate-y-2 hover:border-brand-300/30">
                <span
                  className="pointer-events-none absolute -top-3 end-5 font-display text-7xl font-black text-cream-50/[0.05] transition-colors duration-500 group-hover:text-brand-400/15"
                  aria-hidden="true"
                >
                  {s.num}
                </span>
                <span className="grid size-12 place-items-center rounded-2xl bg-gradient-to-bl from-brand-300 to-brand-600 text-ink-950 shadow-[0_10px_28px_-8px_rgba(238,169,71,0.6)] transition-transform duration-500 group-hover:rotate-[-8deg] group-hover:scale-110">
                  <s.icon className="size-5" strokeWidth={2.3} />
                </span>
                <h3 className="mt-5 font-display text-xl font-extrabold text-cream-50">{s.title}</h3>
                <p className="mt-2.5 text-[15px] leading-7 text-cream-300/90">{s.desc}</p>
                {i < steps.length - 1 && (
                  <span
                    className="absolute top-1/2 -end-3 hidden h-px w-6 bg-gradient-to-l from-brand-400/60 to-transparent md:block"
                    aria-hidden="true"
                  />
                )}
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
