import { useEffect, useState } from "react";
import { motion, AnimatePresence, useSpring, useMotionValue, useTransform } from "framer-motion";
import { Flame, ShoppingBag, Menu, X } from "lucide-react";
import { cn } from "../utils/cn";

const links = [
  { href: "#menu", label: "القائمة" },
  { href: "#features", label: "لماذا بروفايل" },
  { href: "#experience", label: "التجربة" },
  { href: "#plans", label: "الباقات" },
  { href: "#faq", label: "الأسئلة" },
];

function CartBadge({ count }: { count: number }) {
  const mv = useMotionValue(count);
  const spring = useSpring(mv, { stiffness: 500, damping: 22 });
  const scale = useTransform(spring, [Math.max(0, count - 1), count], [1.6, 1]);

  useEffect(() => {
    mv.set(count);
  }, [count, mv]);

  return (
    <motion.span
      style={{ scale }}
      className={cn(
        "absolute -top-1.5 -end-1.5 grid size-5 place-items-center rounded-full text-[11px] font-black tnum",
        count > 0
          ? "bg-gradient-to-bl from-brand-300 to-brand-600 text-ink-950"
          : "bg-ink-700 text-cream-300"
      )}
      aria-live="polite"
      aria-label={`${count} أصناف في الطلب`}
    >
      {count}
    </motion.span>
  );
}

export default function Navbar({ cartCount }: { cartCount: number }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-x-0 top-0 z-50"
    >
      <div
        className={cn(
          "mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 transition-all duration-500 sm:px-8",
          scrolled ? "py-3" : "py-5"
        )}
      >
        <div
          className={cn(
            "pointer-events-none absolute inset-0 transition-opacity duration-500",
            scrolled ? "opacity-100" : "opacity-0"
          )}
          aria-hidden="true"
        >
          <div className="absolute inset-0 bg-ink-950/70 backdrop-blur-2xl" />
          <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-l from-transparent via-brand-400/30 to-transparent" />
        </div>

        {/* Logo */}
        <a href="#top" className="relative z-10 flex items-center gap-2.5" aria-label="مطعم بروفايل — الرئيسية">
          <span className="grid size-10 place-items-center rounded-2xl bg-gradient-to-bl from-brand-300 to-brand-600 shadow-[0_8px_24px_-6px_rgba(238,169,71,0.6)]">
            <Flame className="size-5 text-ink-950" strokeWidth={2.4} />
          </span>
          <span className="font-display text-xl font-black tracking-tight text-cream-50">
            بروفايل<span className="text-brand-400">.</span>
          </span>
        </a>

        {/* Desktop links */}
        <nav className="relative z-10 hidden items-center gap-1 lg:flex" aria-label="التنقل الرئيسي">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="rounded-full px-4 py-2 text-[14px] font-semibold text-cream-200/80 transition-all duration-300 hover:bg-cream-50/[0.06] hover:text-cream-50"
            >
              {l.label}
            </a>
          ))}
        </nav>

        {/* Actions */}
        <div className="relative z-10 flex items-center gap-2.5">
          <a
            href="#menu"
            className="relative grid size-11 place-items-center rounded-full glass text-cream-100 transition-all duration-300 hover:border-brand-300/40 hover:text-brand-200"
            aria-label="عرض طلبي الحالي"
          >
            <ShoppingBag className="size-[18px]" />
            <CartBadge count={cartCount} />
          </a>

          <a
            href="#cta"
            className="group relative hidden items-center gap-2 overflow-hidden rounded-full px-6 py-3 text-[14px] font-black text-ink-950 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_14px_40px_-8px_rgba(238,169,71,0.65)] sm:inline-flex"
          >
            <span className="absolute inset-0 rounded-full bg-gradient-to-bl from-brand-300 via-brand-400 to-brand-600" aria-hidden="true" />
            <span className="relative">اطلب الآن</span>
          </a>

          <button
            type="button"
            onClick={() => setOpen(!open)}
            className="grid size-11 place-items-center rounded-full glass text-cream-100 lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? "إغلاق القائمة" : "فتح القائمة"}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.nav
            id="mobile-menu"
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="mx-4 rounded-3xl glass-strong p-4 lg:hidden"
            aria-label="قائمة الجوال"
          >
            <ul className="flex flex-col">
              {links.map((l, i) => (
                <motion.li
                  key={l.href}
                  initial={{ opacity: 0, x: 24 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 * i, duration: 0.4 }}
                >
                  <a
                    href={l.href}
                    onClick={() => setOpen(false)}
                    className="flex items-center justify-between rounded-2xl px-4 py-3.5 text-base font-bold text-cream-100 transition-colors hover:bg-cream-50/[0.06]"
                  >
                    {l.label}
                    <span className="size-1.5 rounded-full bg-brand-400/70" aria-hidden="true" />
                  </a>
                </motion.li>
              ))}
              <li className="mt-2 pt-2 border-t border-cream-50/10">
                <a
                  href="#cta"
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-bl from-brand-300 to-brand-600 px-4 py-3.5 text-base font-black text-ink-950"
                >
                  اطلب الآن
                </a>
              </li>
            </ul>
          </motion.nav>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
