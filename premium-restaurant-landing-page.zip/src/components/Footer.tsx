import type { SVGProps } from "react";
import { Flame, MapPin, Phone, Mail, Clock } from "lucide-react";

function InstagramIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  );
}
function XIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  );
}
function TikTokIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
    </svg>
  );
}

const quickLinks = [
  { href: "#menu", label: "قائمة الطعام" },
  { href: "#features", label: "لماذا بروفايل" },
  { href: "#experience", label: "تجربتنا" },
  { href: "#plans", label: "باقات الاشتراك" },
  { href: "#faq", label: "الأسئلة الشائعة" },
];

const menuLinks = ["المقبلات", "الأطباق الرئيسية", "المشويات", "الحلو والمشروبات", "قائمة المناسبات"];

const socials = [
  { icon: InstagramIcon, label: "إنستغرام بروفايل", href: "#" },
  { icon: XIcon, label: "حساب بروفايل على X", href: "#" },
  { icon: TikTokIcon, label: "حساب بروفايل على تيك توك", href: "#" },
];

export default function Footer() {
  return (
    <footer className="relative border-t border-cream-50/[0.07] bg-ink-900/50" aria-label="تذييل الموقع">
      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-12">
          {/* brand */}
          <div className="lg:col-span-5">
            <a href="#top" className="flex items-center gap-2.5" aria-label="مطعم بروفايل — الرئيسية">
              <span className="grid size-10 place-items-center rounded-2xl bg-gradient-to-bl from-brand-300 to-brand-600">
                <Flame className="size-5 text-ink-950" strokeWidth={2.4} />
              </span>
              <span className="font-display text-xl font-black text-cream-50">
                بروفايل<span className="text-brand-400">.</span>
              </span>
            </a>
            <p className="mt-5 max-w-sm text-[15px] leading-8 text-cream-300">
              مطعم بروفايل — نكهة تُعرّف عنك. مكونات طازجة، فحم حقيقي، وتجربة ضيافة صُممت لتليق بذوقك، منذ 2013.
            </p>
            <div className="mt-6 flex gap-3">
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  className="grid size-10 place-items-center rounded-full glass text-cream-200 transition-all duration-300 hover:-translate-y-1 hover:border-brand-300/40 hover:text-brand-300"
                >
                  <s.icon className="size-4" />
                </a>
              ))}
            </div>
          </div>

          {/* links */}
          <nav className="lg:col-span-2" aria-label="روابط سريعة">
            <h3 className="font-display text-sm font-black tracking-wide text-cream-100">الموقع</h3>
            <ul className="mt-5 space-y-3">
              {quickLinks.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="text-sm text-cream-300/85 transition-colors hover:text-brand-300">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <nav className="lg:col-span-2" aria-label="روابط القائمة">
            <h3 className="font-display text-sm font-black tracking-wide text-cream-100">القائمة</h3>
            <ul className="mt-5 space-y-3">
              {menuLinks.map((m) => (
                <li key={m}>
                  <a href="#menu" className="text-sm text-cream-300/85 transition-colors hover:text-brand-300">
                    {m}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* contact */}
          <div className="lg:col-span-3">
            <h3 className="font-display text-sm font-black tracking-wide text-cream-100">تواصل معنا</h3>
            <ul className="mt-5 space-y-4 text-sm text-cream-300/85">
              <li className="flex items-center gap-3">
                <MapPin className="size-4 shrink-0 text-brand-400" aria-hidden="true" />
                الرياض — حي العليا، طريق الملك فهد
              </li>
              <li className="flex items-center gap-3" dir="ltr">
                <span dir="rtl" className="flex items-center gap-3">
                  <Phone className="size-4 shrink-0 text-brand-400" aria-hidden="true" />
                  <span className="tnum">920 000 123</span>
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="size-4 shrink-0 text-brand-400" aria-hidden="true" />
                <span dir="ltr">hello@brofeel.sa</span>
              </li>
              <li className="flex items-center gap-3">
                <Clock className="size-4 shrink-0 text-brand-400" aria-hidden="true" />
                يومياً: 12 ظهراً — 12 منتصف الليل
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-cream-50/[0.07] pt-8 sm:flex-row">
          <p className="text-[13px] text-cream-400">
            © <span className="tnum">2026</span> مطعم بروفايل. جميع الحقوق محفوظة.
          </p>
          <div className="flex items-center gap-6 text-[13px] text-cream-400">
            <a href="#top" className="transition-colors hover:text-brand-300">سياسة الخصوصية</a>
            <a href="#top" className="transition-colors hover:text-brand-300">الشروط والأحكام</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
