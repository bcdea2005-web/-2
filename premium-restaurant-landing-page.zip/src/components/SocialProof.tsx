import { Flame } from "lucide-react";
import { partners, stats } from "../data/content";
import { CountUp, Reveal } from "./ui";

const marqueeItems = [
  "برجر بروفايل سيغنتشر",
  "مشاوي على فحم البلوط",
  "كنافة بالقشطة",
  "سلمون بالأعشاب",
  "موهيتو النعناع الطازج",
  "ألفريدو الترافل",
  "شيش طاووق بالثوم",
  "فوندان الشوكولاتة",
];

export default function SocialProof() {
  return (
    <section id="proof" className="relative" aria-label="الأرقام والشهادات">
      {/* marquee */}
      <div className="relative border-y border-cream-50/[0.07] bg-ink-900/60 py-5" dir="ltr">
        <div className="overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_12%,black_88%,transparent)]">
          <div className="flex w-max animate-marquee gap-10 pr-10">
            {[...marqueeItems, ...marqueeItems].map((m, i) => (
              <span key={i} className="flex items-center gap-10 whitespace-nowrap" dir="rtl">
                <span className="font-display text-lg font-extrabold text-cream-200/70">{m}</span>
                <Flame className="size-4 text-brand-500/70" aria-hidden="true" />
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8 sm:py-20">
        {/* partners */}
        <Reveal>
          <p className="text-center text-sm font-semibold tracking-wide text-cream-400">
            طلباتنا تصلك عبر منصاتك المفضلة
          </p>
        </Reveal>
        <Reveal delay={0.1}>
          <ul className="mt-7 flex flex-wrap items-center justify-center gap-x-10 gap-y-4" aria-label="شركاء التوصيل">
            {partners.map((p) => (
              <li
                key={p}
                className="font-display text-xl font-black text-cream-50/25 transition-all duration-500 hover:text-cream-50/60"
              >
                {p}
              </li>
            ))}
          </ul>
        </Reveal>

        {/* stats */}
        <div className="mt-16 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((s, i) => (
            <Reveal key={s.label} delay={i * 0.08}>
              <div className="group relative overflow-hidden rounded-3xl glass p-6 text-center transition-all duration-500 hover:-translate-y-1.5 hover:border-brand-300/30 sm:p-8">
                <div
                  className="pointer-events-none absolute inset-x-8 top-0 h-px bg-gradient-to-l from-transparent via-brand-300/50 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100"
                  aria-hidden="true"
                />
                <CountUp
                  value={s.value}
                  decimals={s.decimals}
                  suffix={s.suffix}
                  className="block font-display text-4xl font-black text-brand-gradient sm:text-5xl"
                />
                <p className="mt-2.5 text-sm font-semibold text-cream-300">{s.label}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
