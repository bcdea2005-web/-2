import { Flame, CalendarCheck, ShieldCheck, Truck } from "lucide-react";
import { ambienceVideo, heroImages } from "../data/content";
import { Reveal, GlowButton } from "./ui";

const assurances = [
  { icon: Truck, label: "توصيل خلال 30 دقيقة" },
  { icon: ShieldCheck, label: "ضمان استرداد 14 يوماً" },
  { icon: CalendarCheck, label: "حجز خلال دقيقة" },
];

export default function CTA() {
  return (
    <section id="cta" className="relative px-5 py-20 sm:px-8 sm:py-28" aria-labelledby="cta-title">
      <div className="relative mx-auto max-w-6xl overflow-hidden rounded-[2.5rem] ring-gradient">
        {/* video backdrop */}
        <div className="absolute inset-0" aria-hidden="true">
          <video
            className="h-full w-full object-cover"
            src={ambienceVideo}
            poster={heroImages.chef}
            autoPlay
            muted
            loop
            playsInline
            preload="metadata"
          />
          <div className="absolute inset-0 bg-ink-950/78" />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/40 to-ink-950/70" />
          <div className="absolute -top-20 start-1/4 size-96 rounded-full bg-brand-500/20 blur-[110px]" />
        </div>

        <div className="relative px-6 py-20 text-center sm:px-12 sm:py-28">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full glass-strong px-4 py-2 text-[13px] font-bold text-brand-200">
              <Flame className="size-4 text-brand-300" aria-hidden="true" />
              أول طلب لك — خصم 20% بكود BROFEEL20
            </span>
          </Reveal>

          <Reveal delay={0.1}>
            <h2
              id="cta-title"
              className="balanced mx-auto mt-7 max-w-3xl font-display text-4xl font-black leading-[1.2] text-cream-50 sm:text-5xl lg:text-6xl"
            >
              طاولتك جاهزة،
              <br />
              <span className="text-brand-gradient">والنكهة تنتظر توقيعك</span>
            </h2>
          </Reveal>

          <Reveal delay={0.18}>
            <p className="mx-auto mt-6 max-w-xl text-lg leading-9 text-cream-200">
              احجز طاولتك لهذا المساء، أو اطلب قائمتك المفضلة إلى باب منزلك — تجربة بروفايل تبدأ بضغطة واحدة.
            </p>
          </Reveal>

          <Reveal delay={0.26}>
            <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
              <GlowButton href="#top" className="px-9 py-4 text-base" ariaLabel="احجز طاولتك الآن">
                احجز طاولتك الآن
              </GlowButton>
              <GlowButton href="#menu" variant="ghost" className="px-9 py-4 text-base" ariaLabel="تصفح القائمة الكاملة">
                تصفح القائمة الكاملة
              </GlowButton>
            </div>
          </Reveal>

          <Reveal delay={0.34}>
            <ul className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-3">
              {assurances.map((a) => (
                <li key={a.label} className="flex items-center gap-2 text-sm font-semibold text-cream-200">
                  <a.icon className="size-4 text-brand-300" aria-hidden="true" />
                  {a.label}
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
