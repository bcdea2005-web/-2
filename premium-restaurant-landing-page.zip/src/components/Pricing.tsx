import { Check, Crown } from "lucide-react";
import { plans } from "../data/content";
import { Reveal, SectionHeading, GlowButton } from "./ui";
import { cn } from "../utils/cn";

export default function Pricing() {
  return (
    <section id="plans" className="relative py-20 sm:py-28" aria-labelledby="plans-title">
      <div
        className="pointer-events-none absolute end-[-10%] top-1/3 size-[460px] rounded-full bg-brand-500/[0.07] blur-[130px]"
        aria-hidden="true"
      />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          id="plans-title"
          tag="باقات الاشتراك"
          title="وفّر وقتك،"
          highlight="ودع النكهة علينا"
          description="باقات شهرية مرنة للأفراد — وجباتك مجدولة، مدروسة السعرات، وتصل في موعدها. أوقفها متى شئت بلا رسوم."
        />

        <div className="mt-14 grid items-stretch gap-6 lg:grid-cols-3">
          {plans.map((p, i) => (
            <Reveal key={p.id} delay={i * 0.12} className="h-full">
              <article
                className={cn(
                  "relative flex h-full flex-col rounded-[2rem] p-8 transition-all duration-500 hover:-translate-y-2",
                  p.popular
                    ? "ring-gradient bg-ink-800/80 shadow-[0_40px_90px_-30px_rgba(238,169,71,0.35)] lg:scale-[1.045]"
                    : "glass hover:border-brand-300/30"
                )}
              >
                {p.popular && (
                  <span className="absolute -top-4 start-1/2 flex -translate-x-1/2 items-center gap-1.5 rounded-full bg-gradient-to-bl from-brand-300 to-brand-600 px-4 py-1.5 text-xs font-black text-ink-950 shadow-lg">
                    <Crown className="size-3.5" aria-hidden="true" />
                    الأكثر اشتراكاً
                  </span>
                )}

                <h3 className="font-display text-xl font-extrabold text-cream-50">{p.name}</h3>
                <p className="mt-1 text-sm text-cream-400">{p.tagline}</p>

                <div className="mt-6 flex items-end gap-2">
                  <span className="font-display text-5xl font-black text-brand-gradient tnum" dir="ltr">
                    {p.price}
                  </span>
                  <span className="pb-1.5 text-sm font-semibold text-cream-400">ر.س / {p.unit}</span>
                </div>

                <div className="my-6 h-px bg-gradient-to-l from-transparent via-cream-50/15 to-transparent" aria-hidden="true" />

                <ul className="flex-1 space-y-3.5">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 text-[15px] text-cream-200">
                      <span
                        className={cn(
                          "mt-0.5 grid size-5 shrink-0 place-items-center rounded-full",
                          p.popular ? "bg-brand-400/20 text-brand-300" : "bg-cream-50/[0.07] text-cream-300"
                        )}
                      >
                        <Check className="size-3" strokeWidth={3} aria-hidden="true" />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>

                <GlowButton href="#cta" variant={p.popular ? "primary" : "ghost"} className="mt-8 w-full" ariaLabel={p.cta}>
                  {p.cta}
                </GlowButton>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.2}>
          <p className="mt-10 text-center text-sm leading-7 text-cream-400">
            جميع الباقات تشمل ضمان استرداد كامل خلال 14 يوماً —
            <span className="font-bold text-cream-100"> إن لم تعشق التجربة، نعيد لك كل ريال.</span>
          </p>
        </Reveal>
      </div>
    </section>
  );
}
