import { Leaf, ChefHat, Timer, HeartPulse, Flame, ShieldCheck, type LucideIcon } from "lucide-react";
import { features } from "../data/content";
import { Reveal, SectionHeading } from "./ui";

const iconMap: Record<string, LucideIcon> = {
  Leaf,
  ChefHat,
  Timer,
  HeartPulse,
  Flame,
  ShieldCheck,
};

export default function Features() {
  return (
    <section id="features" className="relative py-20 sm:py-28" aria-labelledby="features-title">
      <div
        className="pointer-events-none absolute start-[-15%] top-1/4 size-[480px] rounded-full bg-brand-500/[0.07] blur-[130px]"
        aria-hidden="true"
      />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          id="features-title"
          tag="لماذا بروفايل؟"
          title="لسنا مجرد مطعم،"
          highlight="نحن توقيعك على الطاولة"
          description="كل تفصيلة — من انتقاء المكوّن فجراً إلى وضع آخر لمسة على الطبق — مصممة لتستحق لقب وجبتك المفضلة."
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => {
            const Icon = iconMap[f.icon] ?? Flame;
            return (
              <Reveal key={f.title} delay={(i % 3) * 0.1}>
                <article className="group relative h-full overflow-hidden rounded-[1.75rem] glass p-7 transition-all duration-500 hover:-translate-y-2 hover:border-brand-300/30 hover:shadow-[0_30px_60px_-20px_rgba(238,169,71,0.18)]">
                  {/* hover glow */}
                  <div
                    className="pointer-events-none absolute -end-16 -top-16 size-44 rounded-full bg-brand-400/0 blur-3xl transition-all duration-700 group-hover:bg-brand-400/[0.14]"
                    aria-hidden="true"
                  />
                  <div className="relative">
                    <span className="grid place-items-center rounded-2xl bg-gradient-to-bl from-brand-300/15 to-brand-600/15 border border-brand-300/20 text-brand-300 transition-all duration-500 group-hover:scale-110 group-hover:rotate-[-8deg] group-hover:from-brand-300 group-hover:to-brand-600 group-hover:text-ink-950 size-12">
                      <Icon className="size-5" strokeWidth={2.2} />
                    </span>
                    <h3 className="mt-5 font-display text-xl font-extrabold text-cream-50">{f.title}</h3>
                    <p className="mt-2.5 text-[15px] leading-7 text-cream-300/90">{f.description}</p>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
