import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronDown, MessageCircle } from "lucide-react";
import { faqs } from "../data/content";
import { Reveal, SectionHeading } from "./ui";
import { cn } from "../utils/cn";

function FaqItem({
  q,
  a,
  open,
  onToggle,
  index,
}: {
  q: string;
  a: string;
  open: boolean;
  onToggle: () => void;
  index: number;
}) {
  const panelId = `faq-panel-${index}`;
  const btnId = `faq-btn-${index}`;
  return (
    <div
      className={cn(
        "overflow-hidden rounded-3xl border transition-all duration-500",
        open ? "glass-strong border-brand-300/25" : "glass hover:border-cream-50/20"
      )}
    >
      <h3>
        <button
          type="button"
          id={btnId}
          aria-expanded={open}
          aria-controls={panelId}
          onClick={onToggle}
          className="flex w-full items-center justify-between gap-4 px-6 py-5 text-start"
        >
          <span className="font-display text-base font-extrabold text-cream-50 sm:text-lg">{q}</span>
          <motion.span
            animate={{ rotate: open ? 180 : 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className={cn(
              "grid size-8 shrink-0 place-items-center rounded-full border transition-colors duration-300",
              open ? "border-brand-300/50 bg-brand-400/15 text-brand-300" : "border-cream-50/15 text-cream-300"
            )}
          >
            <ChevronDown className="size-4" aria-hidden="true" />
          </motion.span>
        </button>
      </h3>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            id={panelId}
            role="region"
            aria-labelledby={btnId}
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          >
            <p className="px-6 pb-6 text-[15px] leading-8 text-cream-300">{a}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function FAQ() {
  const [open, setOpen] = useState<number>(0);

  return (
    <section id="faq" className="relative py-20 sm:py-28" aria-labelledby="faq-title">
      <div className="relative mx-auto max-w-3xl px-5 sm:px-8">
        <SectionHeading
          id="faq-title"
          tag="الأسئلة الشائعة"
          title="عندك سؤال؟"
          highlight="غالباً أجبنا عنه هنا"
          description="لم تجد إجابتك؟ فريق الضيافة متاح يومياً من 9 صباحاً حتى منتصف الليل."
        />

        <div className="mt-12 space-y-4">
          {faqs.map((f, i) => (
            <Reveal key={f.q} delay={i * 0.06}>
              <FaqItem
                q={f.q}
                a={f.a}
                index={i}
                open={open === i}
                onToggle={() => setOpen(open === i ? -1 : i)}
              />
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.15} className="mt-10 text-center">
          <a
            href="#cta"
            className="inline-flex items-center gap-2.5 rounded-full glass px-6 py-3 text-sm font-bold text-cream-100 transition-all duration-300 hover:border-brand-300/40 hover:text-brand-200"
          >
            <MessageCircle className="size-4 text-brand-300" aria-hidden="true" />
            تحدث مع فريق الضيافة مباشرة
          </a>
        </Reveal>
      </div>
    </section>
  );
}
