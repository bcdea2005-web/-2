import { Quote, Star } from "lucide-react";
import { testimonials } from "../data/content";
import { Reveal, SectionHeading } from "./ui";
import { cn } from "../utils/cn";

const gradients = [
  "from-brand-300 to-brand-600",
  "from-blush-400 to-brand-600",
  "from-olive-400 to-brand-500",
  "from-brand-200 to-brand-500",
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="relative py-20 sm:py-28" aria-labelledby="testimonials-title">
      <div
        className="pointer-events-none absolute start-1/2 top-0 size-[600px] -translate-x-1/2 rounded-full bg-brand-500/[0.05] blur-[150px]"
        aria-hidden="true"
      />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          id="testimonials-title"
          tag="آراء ضيوفنا"
          title="كلماتهم أصدق"
          highlight="من أي إعلان"
          description="أكثر من 8,400 تقييم موثّق بمتوسط 4.9 من 5 — وهذه عينة مما يقولونه عن تجربة بروفايل."
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.09} className={cn(i === 0 ? "sm:col-span-2 lg:col-span-1" : "")}>
              <figure className="group relative flex h-full flex-col rounded-[1.75rem] glass p-7 transition-all duration-500 hover:-translate-y-2 hover:border-brand-300/30 hover:shadow-[0_30px_60px_-24px_rgba(238,169,71,0.2)]">
                <Quote
                  className="size-8 text-brand-400/40 transition-colors duration-500 group-hover:text-brand-400/70"
                  aria-hidden="true"
                />
                <div className="mt-4 flex gap-1" aria-label={`تقييم ${t.rating} من 5`}>
                  {[...Array(5)].map((_, s) => (
                    <Star
                      key={s}
                      className={cn(
                        "size-3.5",
                        s < Math.round(t.rating) ? "fill-brand-400 text-brand-400" : "text-cream-50/20"
                      )}
                      aria-hidden="true"
                    />
                  ))}
                </div>
                <blockquote className="mt-4 flex-1 text-[15px] leading-8 text-cream-200">"{t.quote}"</blockquote>
                <figcaption className="mt-6 flex items-center gap-3 border-t border-cream-50/[0.08] pt-5">
                  <span
                    className={cn(
                      "grid size-11 shrink-0 place-items-center rounded-full bg-gradient-to-bl font-display text-lg font-black text-ink-950",
                      gradients[i % gradients.length]
                    )}
                    aria-hidden="true"
                  >
                    {t.name[0]}
                  </span>
                  <div>
                    <p className="text-[15px] font-extrabold text-cream-50">{t.name}</p>
                    <p className="text-xs text-cream-400">
                      {t.role} • <span className="text-brand-300/90">{t.dish}</span>
                    </p>
                  </div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
